/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_reg_find("Text=Contact List App", 
		LAST);

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	/* homepage */

	lr_think_time(19);

	web_submit_form("thinking-tester-contact-list.herokuapp.com_2", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	

	return 0;
}
